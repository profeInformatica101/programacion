package com.string;

public class StringUtils {
    public StringUtils() { }  // constructor público
}
